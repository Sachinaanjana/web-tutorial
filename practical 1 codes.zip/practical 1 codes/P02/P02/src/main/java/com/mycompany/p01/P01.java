package com.mycompany.p01;
import java.util.Scanner;
public class P01 
{

    public static void main(String[] args) 
    {
        System.out.println("Jeneesha Priyadarshani");
        System.out.print("BSc honors in computer science");        
    }
}
